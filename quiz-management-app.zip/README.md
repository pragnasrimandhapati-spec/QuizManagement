# Quizly — Quiz Management App

A responsive quiz management app built with HTML, CSS, Bootstrap 5, vanilla JavaScript, Firebase Authentication, and Cloud Firestore.

## Features

- Student and administrator registration/login
- Admin quiz creation, editing, publishing, and deletion
- Multiple choice questions with configurable correct answers
- Student quiz-taking flow, score calculation, and saved attempts
- Student score summaries and an admin recent-attempts view
- Responsive layout, animated quiz cards, and a Firebase-free landing preview

## Run locally

1. Create a Firebase project at [Firebase Console](https://console.firebase.google.com/).
2. In **Authentication → Sign-in method**, enable **Email/Password**.
3. Create a Cloud Firestore database.
4. Copy your Firebase web app configuration into `firebase-config.js`.
5. In Firestore **Rules**, paste `firestore.rules`. Replace `admin@example.com` with each administrator email address allowed to register. Admin accounts must use one of those exact email addresses.
6. Serve this folder from a local web server (for example, VS Code Live Server or `python -m http.server 8000`) and open the served URL. Firebase Auth does not support opening the app from a `file://` URL.
7. Register an account as Student or Admin. Admin registration succeeds only when the email is present in the rules allowlist.

The app uses Firebase's compat SDK from Google's CDN. A network connection is required. The `firebase-config.js` file contains placeholder values until you add your own project settings.

## Data model

- `users/{uid}` — display name, email, selected role, and creation time
- `quizzes/{quizId}` — title, description, questions/options/correct answer indexes, publishing state, and owner
- `attempts/{attemptId}` — quiz, student, score, answers, and completion time

## Security note

The supplied Firestore rules restrict administrator access to email addresses explicitly listed in `allowedAdmin()`. Keep the allowlist narrow. For larger deployments, use a trusted server or Cloud Functions to provision administrator roles and validate score submissions; browser code should not be treated as a trusted source for grading.
